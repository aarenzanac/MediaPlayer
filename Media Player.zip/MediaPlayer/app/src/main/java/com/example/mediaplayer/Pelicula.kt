package com.example.mediaplayer

import android.widget.VideoView

data class Pelicula (var video: VideoView, var titulo: String){


}