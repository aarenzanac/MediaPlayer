package com.example.mediaplayer

import java.io.File

object Constant {
    var videoExtensions = arrayOf(".mp4", ".ts", ".mkv", ".mov",
            ".3gp", ".mv2", ".m4v", ".webm", ".mpeg1", ".mpeg2", ".mts", ".ogm",
            ".bup", ".dv", ".flv", ".m1v", ".m2ts", ".mpeg4", ".vlc", ".3g2",
            ".avi", ".mpeg", ".mpg", ".wmv", ".asf")


    var allMediaList: ArrayList<File> = ArrayList()
}